class MOSquare1 {

    void calcArea() {
        int a = 10;
        int area = a * a;
        System.out.println("Area of Square: " + area);
    }
}
  class MOSquare{
    public static void main(String[] args) {
      MOSquare1 s = new MOSquare1();
      s.calcArea();

    }

}
