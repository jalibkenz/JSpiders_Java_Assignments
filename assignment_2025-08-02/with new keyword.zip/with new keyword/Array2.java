public class Array2 {
    public static void main(String[] args) {
        double[] b = new double[]{1.1, 2.2};
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i] + " ");
        }
    }
}