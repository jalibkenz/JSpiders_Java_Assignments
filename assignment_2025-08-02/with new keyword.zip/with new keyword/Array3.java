public class Array3 {
    public static void main(String[] args) {
        char[] c = new char[]{'A', 'B', 'C'};
        for (int i = 0; i < c.length; i++) {
            System.out.print(c[i] + " ");
        }
    }
}