public class Array6 {
    public static void main(String[] args) {
        float[] f = new float[]{1.2f, 3.4f};
        for (int i = 0; i < f.length; i++) {
            System.out.print(f[i] + " ");
        }
    }
}