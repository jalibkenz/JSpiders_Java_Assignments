public class Array8 {
    public static void main(String[] args) {
        byte[] h = new byte[]{10, 20};
        for (int i = 0; i < h.length; i++) {
            System.out.print(h[i] + " ");
        }
    }
}