public class Array7 {
    public static void main(String[] args) {
        long[] g = new long[]{100L, 200L};
        for (int i = 0; i < g.length; i++) {
            System.out.print(g[i] + " ");
        }
    }
}