public class Array5 {
    public static void main(String[] args) {
        boolean[] e = {true, false};
        for (int i = 0; i < e.length; i++) {
            System.out.print(e[i] + " ");
        }
    }
}