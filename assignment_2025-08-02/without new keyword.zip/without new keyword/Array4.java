public class Array4 {
    public static void main(String[] args) {
        String[] d = {"One", "Two"};
        for (int i = 0; i < d.length; i++) {
            System.out.print(d[i] + " ");
        }
    }
}